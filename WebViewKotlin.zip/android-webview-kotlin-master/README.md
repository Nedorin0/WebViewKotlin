# android-webview-kotlin
An android application to load website in webview using Koltin
